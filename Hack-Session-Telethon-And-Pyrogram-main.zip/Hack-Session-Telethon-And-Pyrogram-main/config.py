class Config:
    API_ID = 7715737 #خلي مثل ماهوه
    API_HASH = "241e23bd490bfad03f0da62d4f5d8a20" #خلي مثل ماهوه
    TOKEN = "59758258166:AAEuANb_008uAgVJwQWeDKUYlK5qBMuN8MMT0"  #توكن
    START_PIC = "https://graph.org/file/9ffcff556e24e0c37e444.jpg" #هنا حط رابط صورة تلكراف
    CHAT = "-1001852789435" #وهنا خلي ايدي كروب التخزين 



