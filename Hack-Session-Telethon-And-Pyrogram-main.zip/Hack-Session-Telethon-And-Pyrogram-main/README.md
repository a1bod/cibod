# بوت اختراق كود تيرمكس وبايروجرام 


## Thanks To 🙏:
[Hussien](https://github.com/SS7SS)